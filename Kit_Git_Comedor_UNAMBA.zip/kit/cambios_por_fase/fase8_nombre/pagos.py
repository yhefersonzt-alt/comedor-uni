# pagos.py - Pagos y emisión de ticket (RF06, RF07)

from config import PRECIO_RACION


def registrar_pago(estudiante, monto):
    """Registra el pago de una ración (RF06)."""
    return monto >= PRECIO_RACION


def emitir_ticket(estudiante, monto):
    """Emite el ticket de la ración (RF07)."""
    return f"TICKET | {estudiante} | S/ {monto:.2f}"
