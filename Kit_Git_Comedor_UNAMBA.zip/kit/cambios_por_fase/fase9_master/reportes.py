# reportes.py - Reportes diarios (RF11)


def raciones_servidas(registros):
    return len(registros)


def ingresos(registros, precio):
    return len(registros) * precio


def asistencia(registros):
    return len(set(registros))


def merma(preparadas, servidas):
    """Raciones preparadas que no se sirvieron."""
    return preparadas - servidas
